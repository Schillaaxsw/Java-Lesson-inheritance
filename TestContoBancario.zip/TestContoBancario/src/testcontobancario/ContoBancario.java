/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testcontobancario;

/**
 *
 * @author schillaci.gabriel
 */
public class ContoBancario {

    private String ContoCorrente;
    int bilancio;

    public ContoBancario(int bilancio) {
        this.bilancio = 0;
    }

    public ContoBancario(String ContoCorrente, int bilancio) {
        this.ContoCorrente = ContoCorrente;
        this.bilancio = bilancio;
    }

    public String getContoCorrente() {
        return ContoCorrente;
    }

    public void setContoCorrente(String ContoCorrente) {
        this.ContoCorrente = ContoCorrente;
    }

    public int getBilancio() {
        return bilancio;
    }

    public void setBilancio(int bilancio) {
        this.bilancio = bilancio;
    }

    public void prelievo(int prelievo) {
        if (bilancio > 0) {
            bilancio -= prelievo;
        }
    }

    public void deposito(int deposito) {
        bilancio += deposito;
    }

}
