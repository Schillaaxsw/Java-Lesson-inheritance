/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testcontobancario;

/**
 *
 * @author schillaci.gabriel
 */
public class ContoEsteso extends ContoBancario {

    private int fido;

    public ContoEsteso(int bilancio) {
        super(bilancio);
    }

    public ContoEsteso(String ContoCorrente, int bilancio) {
        super(ContoCorrente, bilancio);
        this.fido = 1000;
    }

    public ContoEsteso(int fido, int bilancio) {
        super(bilancio);
        this.fido = fido;
    }

    public ContoEsteso(int fido, String ContoCorrente, int bilancio) {
        super(ContoCorrente, bilancio);
        this.fido = fido;
    }

    public int getFido() {
        return fido;
    }

    public void setFido(int fido) {
        this.fido = fido;
    }
    @override

    public int prelievo {
        int prelievo = 0;
        do {

            if (bilancio + fido > prelievo) {
                bilancio = bilancio - prelievo;

            }
